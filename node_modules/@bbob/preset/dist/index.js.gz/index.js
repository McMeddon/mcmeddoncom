(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
    typeof define === 'function' && define.amd ? define(['exports'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.BbobPreset = {}));
})(this, (function (exports) { 'use strict';

    /* eslint-disable indent */ var isTagNode = function(el) {
        return typeof el === 'object' && !!el.tag;
    };
    function process(tags, tree, core, options) {
        tree.walk(function(node) {
            return isTagNode(node) && tags[node.tag] ? tags[node.tag](node, core, options) : node;
        });
    }
    /**
     * Creates preset for @bbob/core
     * @param defTags {Object}
     * @param processor {Function} a processor function of tree
     * @returns {function(*=): function(*=, *=): void}
     */ function createPreset(defTags, param) {
        var processor = param === void 0 ? process : param;
        var presetFactory = function(param) {
            var opts = param === void 0 ? {
            } : param;
            presetFactory.options = Object.assign(presetFactory.options || {
            }, opts);
            var presetExecutor = function(tree, core) {
                return processor(defTags, tree, core, presetFactory.options);
            };
            presetExecutor.options = presetFactory.options;
            return presetExecutor;
        };
        presetFactory.extend = function(callback) {
            return createPreset(callback(defTags, presetFactory.options), processor);
        };
        return presetFactory;
    }

    exports.createPreset = createPreset;
    exports["default"] = createPreset;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
